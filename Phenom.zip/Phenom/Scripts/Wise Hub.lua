loadstring(game:HttpGet(("https://pastebin.com/raw/3m0agkEg"), true))()
