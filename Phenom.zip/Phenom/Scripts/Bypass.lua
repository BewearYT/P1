local meta, old = getrawmetatable(game), {};
for i, v in next, meta do old[i] = v end;

local char = 'ٓأأ';

setreadonly(meta, false);

meta.__namecall = newcclosure(function(...)
local method = getnamecallmethod();
local args = {...};
local replacetext = {"nigger", "", "thot", "bitch", "cunt", "fuck", "fucker", "whore", "dick", "penis", "asshole", "allahu", "akbar", "crap", "shit", "motherfucker", "girlfriend", "boyfriend", "slave", "sex", "pussy", "nigga", "slut", "rape", "cock", "dick", "porn", "pornhub", "hentai", "tits", "vagina", "pussy", "cunt", "jew", "hitler", "fucking", "bitches", "asshole", "suck", "hoe", "cum", "jizz", "sperm"}
local replacedtext = ""

if method == 'FireServer' and args[1].Name == 'SayMessageRequest' then
 for count = 1, 24 do
   if string.find(args[2], replacetext[count]) then
     replacedtext = string.gsub(replacetext[count], '.', function(c)
     return c .. char;
     end);
     args[2] = string.gsub(args[2], replacetext[count], replacedtext);
   end;
   end;
return old.__namecall(unpack(args));
   end;

   return old.__namecall(...);
   end);

   setreadonly(meta, true);
