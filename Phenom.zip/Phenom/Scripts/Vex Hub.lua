--Join Discord for key: bwQzYnh
loadstring(game:HttpGet("https://pastebin.com/raw/1afKL3TU", true))()
