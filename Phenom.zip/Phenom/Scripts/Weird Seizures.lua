local plr = game:GetService('Players').LocalPlayer
local bruh = Instance.new('BodyAngularVelocity',plr.Character.Head)
bruh.MaxTorque = Vector3.new(965349064950,965349064950,965349064950)
bruh.AngularVelocity = Vector3.new(0,1000,0)