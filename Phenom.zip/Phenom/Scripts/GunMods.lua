loadstring(game:HttpGet('https://whitelistcheck.com/scripts/GunModHub.lua'))()
