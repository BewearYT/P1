---Wank V.1
while wait(0.5) do 
local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://174347769"
local Plr = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
Plr:Play()
Plr:AdjustSpeed(1)
end