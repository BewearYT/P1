loadstring(game:HttpGet(('https://raw.githubusercontent.com/ThisUserNameIsUnavailable/Lucid/master/Init'),true))();
