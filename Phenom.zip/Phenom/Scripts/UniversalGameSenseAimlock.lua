--[[
	Games:

	Arsenal
	Phantom Forces
	Big Paintball

--]]


loadstring(game:HttpGet("https://pastebin.com/raw/MmhRhnXi"))()