loadstring(game:HttpGet("https://pastebin.com/raw/RmD3qNp7", true))()
