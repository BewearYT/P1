loadstring(game:HttpGet(('https://pastebin.com/raw/R2beZEUw'),true))()

--Bakiez, Koala Cafe, Soros, Bloxton Hotels