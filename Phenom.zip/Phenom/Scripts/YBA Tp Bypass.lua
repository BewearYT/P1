game.workspace.Living[game.Players.LocalPlayer.Name].RemoteFunction:Destroy()

