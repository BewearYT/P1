local plr = game.Players.LocalPlayer
for i,v in pairs(workspace.Map:GetDescendants()) do
   if v:IsA("ClickDetector") then
       plr.Character.HumanoidRootPart.CFrame = v.Parent.PrimaryPart.CFrame
       wait(1)
       fireclickdetector(v)
   end
end

